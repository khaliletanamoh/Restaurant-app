// Usage:  node tools/set_role.js <uid> <customer|staff|manager>
// Needs a service account:  export GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json
// (run `npm install firebase-admin` once in this folder or in functions/)
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');

const [uid, role] = process.argv.slice(2);
if (!uid || !['customer', 'staff', 'manager'].includes(role)) {
  console.error('Usage: node tools/set_role.js <uid> <customer|staff|manager>');
  process.exit(1);
}
initializeApp();
getAuth()
  .setCustomUserClaims(uid, { role })
  .then(() => console.log(`Role "${role}" set for ${uid}. The user must sign out and in again (or wait up to 1 hour).`))
  .catch((e) => { console.error(e); process.exit(1); });
